# README
This is advance version of ItsMe Prince shop which is made in Express.js and MongoDB and uses EJS library for html pages. Through this we can easily enter the data into the database and access all the data from the database and manipulate those data as well. Its also my first project where I've used such database and made backend and stuff. It was really great!
